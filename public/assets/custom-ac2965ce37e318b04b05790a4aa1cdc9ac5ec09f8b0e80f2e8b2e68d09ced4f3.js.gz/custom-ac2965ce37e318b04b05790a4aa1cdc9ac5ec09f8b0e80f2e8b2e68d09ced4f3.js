// var delayTimer;
// $(window).ready(function () {
//     $(".line-container").click(function(){
//         $(this).parent().find("#sharing_list").toggleClass("d-block").toggleClass("d-none");
//     })
// });
//
//;
